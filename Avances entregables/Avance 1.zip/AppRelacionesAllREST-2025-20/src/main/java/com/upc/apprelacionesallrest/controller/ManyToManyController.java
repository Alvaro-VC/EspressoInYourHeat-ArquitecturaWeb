package com.upc.apprelacionesallrest.controller;

import com.upc.apprelacionesallrest.model.manyToMany.Stream;
import com.upc.apprelacionesallrest.model.manyToMany.Viewer;
import com.upc.apprelacionesallrest.negocio.Negocio;
import com.upc.apprelacionesallrest.repository.oneToMany.unidirectional.StudentRepository;
import com.upc.apprelacionesallrest.repository.oneToOne.bidirectional.OwnerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class ManyToManyController {
    @Autowired
    private Negocio negocio;
    @PostMapping("/viewver")
    public void registrarViewer(@RequestBody Viewer viewer){
        System.out.println("Ok");
        negocio.registrarViewer(viewer);
    }

    @PostMapping("/viewer/{id_viewer}/{id_stream}")
    public Integer grabarTablaIntermediaManytoMany(@PathVariable(name="id_viewer") Long id_viever,
                                                   @PathVariable(name = "id_stream") Long id_stream) {
        return negocio.grabarTablaIntermediaManytoMany(id_viever, id_stream);
    }
    @PostMapping("/stream")
    public Stream registrarStream(@RequestBody Stream stream){
        System.out.println("Ok");
        return negocio.registrarStream(stream);
    }

}
