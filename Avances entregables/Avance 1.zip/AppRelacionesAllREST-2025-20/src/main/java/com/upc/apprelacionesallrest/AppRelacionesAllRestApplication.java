package com.upc.apprelacionesallrest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication
@EnableAsync
public class AppRelacionesAllRestApplication {

	public static void main(String[] args)
    {
		SpringApplication.run(AppRelacionesAllRestApplication.class, args);
	}

}
