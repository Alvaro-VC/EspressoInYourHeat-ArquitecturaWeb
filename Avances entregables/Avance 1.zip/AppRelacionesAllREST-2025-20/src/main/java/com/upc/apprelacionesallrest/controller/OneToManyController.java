package com.upc.apprelacionesallrest.controller;

import com.upc.apprelacionesallrest.model.oneToMany.bidirectional.Cart;
import com.upc.apprelacionesallrest.model.oneToMany.unidirectional.Student;
import com.upc.apprelacionesallrest.model.oneToMany.unidirectional.University;
import com.upc.apprelacionesallrest.negocio.Negocio;
import com.upc.apprelacionesallrest.repository.oneToMany.unidirectional.StudentRepository;
import com.upc.apprelacionesallrest.repository.oneToOne.bidirectional.CarRepository;
import com.upc.apprelacionesallrest.repository.oneToOne.bidirectional.OwnerRepository;
import com.upc.apprelacionesallrest.repository.oneToOne.unidirectional.AddressRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class OneToManyController {

    @Autowired
    private Negocio negocio;

    @GetMapping("/university")
    public List<University> listUniversities(){
        return negocio.listUniversities();
    }

    @PostMapping("/university")
    public University saveCart(@RequestBody University university){
        return negocio.saveUniversity(university);
    }

    @PostMapping("/cart")
    public Cart saveCart(@RequestBody Cart cart){
        return negocio.saveCart(cart);
    }
    @GetMapping("cart/{id}")
    public Cart getCar(@PathVariable("id") Long id) throws Exception {
        return negocio.getCar(id);
    }

    @GetMapping("/students/{id}")
    public List<Student> listStudents(@PathVariable("id") Long id){
        return negocio.listStudents(id);
    }
}
