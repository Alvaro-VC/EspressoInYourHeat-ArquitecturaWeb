package com.upc.apprelacionesallrest.repository.manyToOne;

import com.upc.apprelacionesallrest.model.manyToOne.bidirection.Padre;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PadreRepository extends JpaRepository<Padre, Long> {
}
