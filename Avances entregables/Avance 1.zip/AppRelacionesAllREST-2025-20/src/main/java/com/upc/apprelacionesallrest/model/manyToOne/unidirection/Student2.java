package com.upc.apprelacionesallrest.model.manyToOne.unidirection;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.persistence.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Student2 {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @Column(unique = true)
    private String indexNumber;
    private Boolean status;
    @ManyToOne
    @JoinColumn(name = "university2_id")
    private University2 university2;

}
