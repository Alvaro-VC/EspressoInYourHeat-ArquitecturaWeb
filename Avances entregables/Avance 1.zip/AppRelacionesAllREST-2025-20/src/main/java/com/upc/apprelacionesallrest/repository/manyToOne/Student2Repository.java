package com.upc.apprelacionesallrest.repository.manyToOne;

import com.upc.apprelacionesallrest.model.manyToOne.unidirection.Student2;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Student2Repository extends JpaRepository<Student2, Long> {
}
