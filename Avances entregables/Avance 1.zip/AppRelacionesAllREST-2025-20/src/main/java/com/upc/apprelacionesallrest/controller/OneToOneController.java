package com.upc.apprelacionesallrest.controller;

import com.upc.apprelacionesallrest.model.oneToOne.bidirectional.Car;
import com.upc.apprelacionesallrest.model.oneToOne.bidirectional.Owner;
import com.upc.apprelacionesallrest.model.oneToOne.unidirectional.Address;
import com.upc.apprelacionesallrest.model.oneToOne.unidirectional.User;
import com.upc.apprelacionesallrest.negocio.Negocio;
import com.upc.apprelacionesallrest.repository.oneToMany.unidirectional.StudentRepository;
import com.upc.apprelacionesallrest.repository.oneToOne.bidirectional.CarRepository;
import com.upc.apprelacionesallrest.repository.oneToOne.bidirectional.OwnerRepository;
import com.upc.apprelacionesallrest.repository.oneToOne.unidirectional.AddressRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@RequestMapping("/api")
public class OneToOneController {

    @Autowired
    private Negocio negocio;

    //OneToOne Unidirectional

    @PostMapping("/address")
    public Address saveAddress(@RequestBody Address address){
        return negocio.saveAddress(address);
    }

    @PostMapping("/user")
    public User saveUser(@RequestBody User user){
        return negocio.grabar(user);
    }

    @GetMapping("/user")
    public List<User> listUsers(){
        return negocio.listarUsers();
    }

    //OneToOne Bidirectional

    @PostMapping("/owner")
    public Owner saveOwner(@RequestBody Owner owner){
        return negocio.saveOwner(owner);
    }

    @GetMapping("/owner")
    public List<Owner> listOwners(){
        return negocio.listOwners();
    }

    @PostMapping("/car")
    public Car saveCar(@RequestBody Car car){
        return negocio.saveCar(car);
    }

    @GetMapping("/cars") //OneToOne Bidirectional, sólo cars por JsonIgnore
    public List<Car> getCars(){
        return negocio.getCars();
    }
    @GetMapping("/owners")  //OneToOne Bidirectional
    public List<Owner> getOwners(){
        return negocio.getOwners();
    }
}
