package com.upc.apprelacionesallrest.negocio;

import com.upc.apprelacionesallrest.model.manyToMany.Stream;
import com.upc.apprelacionesallrest.model.manyToMany.Viewer;
import com.upc.apprelacionesallrest.model.manyToOne.bidirection.Hijo;
import com.upc.apprelacionesallrest.model.manyToOne.bidirection.Padre;
import com.upc.apprelacionesallrest.model.manyToOne.unidirection.Student2;
import com.upc.apprelacionesallrest.model.manyToOne.unidirection.University2;
import com.upc.apprelacionesallrest.model.oneToMany.bidirectional.Cart;
import com.upc.apprelacionesallrest.model.oneToMany.unidirectional.Student;
import com.upc.apprelacionesallrest.model.oneToMany.unidirectional.University;
import com.upc.apprelacionesallrest.model.oneToOne.bidirectional.Car;
import com.upc.apprelacionesallrest.model.oneToOne.bidirectional.Owner;
import com.upc.apprelacionesallrest.model.oneToOne.unidirectional.Address;
import com.upc.apprelacionesallrest.model.oneToOne.unidirectional.User;
import com.upc.apprelacionesallrest.repository.manyToMany.StreamRepository;
import com.upc.apprelacionesallrest.repository.manyToMany.ViewerRepository;
import com.upc.apprelacionesallrest.repository.manyToOne.HijoRepository;
import com.upc.apprelacionesallrest.repository.manyToOne.PadreRepository;
import com.upc.apprelacionesallrest.repository.manyToOne.Student2Repository;
import com.upc.apprelacionesallrest.repository.manyToOne.University2Repository;
import com.upc.apprelacionesallrest.repository.oneToMany.bidirectional.CartRepository;
import com.upc.apprelacionesallrest.repository.oneToMany.unidirectional.StudentRepository;
import com.upc.apprelacionesallrest.repository.oneToMany.unidirectional.UniversityRepository;
import com.upc.apprelacionesallrest.repository.oneToOne.bidirectional.CarRepository;
import com.upc.apprelacionesallrest.repository.oneToOne.bidirectional.OwnerRepository;
import com.upc.apprelacionesallrest.repository.oneToOne.unidirectional.AddressRepository;
import com.upc.apprelacionesallrest.repository.oneToOne.unidirectional.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

@Service
public class Negocio {
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private OwnerRepository ownerRepository;

    @Autowired
    private UniversityRepository universityRepository;
    @Autowired
    private Student2Repository student2Repository;
    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private University2Repository university2Repository;
    @Autowired
    private CartRepository cartRepository;
    @Autowired
    private ViewerRepository viewerRepository;
    @Autowired
    private StreamRepository streamRepository;
    @Autowired
    private AddressRepository addressRepository;
    @Autowired
    private CarRepository carRepository;
    @Autowired
    private PadreRepository padreRepository;
    @Autowired
    private HijoRepository hijoRepository;


    @Transactional
    public User grabar(User user){
      return userRepository.save(user);
    }

    public List<User> listarUsers() {
        return userRepository.findAll();
    }

    public List<Owner> listOwners() {
        return ownerRepository.findAll();
    }

    public University saveUniversity(University university) {
       return universityRepository.save(university);
    }
    public University2 saveUniversity2(University2 university2) {
        return university2Repository.save(university2);
    }
    public Student saveStudent(Student student) {
        return studentRepository.save(student);
    }
    public Student2 saveStudent2(Student2 student2) {
        return student2Repository.save(student2);
    }

    public List<University> listUniversities() {
        return universityRepository.findAll();
    }
    public List<University2> listUniversities2() {
        return university2Repository.findAll();
    }
    public List<Student2> listStundents2() {
        return student2Repository.findAll();
    }

    public Cart saveCart(Cart cart) {
        return cartRepository.save(cart);
    }

    public Cart getCar(Long id) throws Exception {
        return cartRepository.findById(id).orElseThrow(() ->new Exception("No existe"));
    }
    @Transactional
    public void registrarViewer(Viewer viewer){
        System.out.println("Ok");
        viewerRepository.save(viewer);
    }
    @Transactional
    public Integer grabarTablaIntermediaManytoMany(Long id_viewer, Long id_stream){
        Viewer xViewer = viewerRepository.findById(id_viewer).get();
        Stream yStream = streamRepository.findById(id_stream).get();
        xViewer.getFollowedStreams().add(yStream);
        viewerRepository.save(xViewer);
        streamRepository.save(yStream);
        return 1;
    }
    @Transactional
    public Address saveAddress(@RequestBody Address address){
        return addressRepository.save(address);
    }

    public Owner saveOwner(@RequestBody Owner owner){
        return ownerRepository.save(owner);
    }

    @Transactional
    public Car saveCar(@RequestBody Car car){
        return carRepository.save(car);
    }
    public List<Car> getCars(){
        return carRepository.findAll();
    }
    public List<Owner> getOwners(){
        return ownerRepository.findAll();
    }
    public Stream registrarStream(Stream stream) {
        return streamRepository.save(stream);
    }

    public List<Student> listStudents(Long id){
        return studentRepository.findStudents(id);
    }
    public Padre savePadre(Padre padre){
        return padreRepository.save(padre);
    }
    public Hijo savePadre(Hijo hijo){
        return hijoRepository.save(hijo);
    }

    public Hijo saveHijo(Hijo hijo) {
        return hijoRepository.save(hijo);
    }
    public List<Padre> listPadres(){
        return padreRepository.findAll();
    }
    public List<Hijo> listHijos(){
        return hijoRepository.findAll();
    }

}
