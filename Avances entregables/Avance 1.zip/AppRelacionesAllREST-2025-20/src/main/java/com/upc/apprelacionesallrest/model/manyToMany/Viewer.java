package com.upc.apprelacionesallrest.model.manyToMany;

import lombok.Data;

import jakarta.persistence.*;

import java.util.HashSet;
import java.util.Set;

@Entity
@Data
@Table(name = "Viewer")
public class Viewer { //Es Propietaria de la relacion
    //un viewer puede tener múltiples streamers, y un streamer puede estar asignado
    // a múltiples viewers. Esto se gestiona mediante una tabla intermedia
    // (followed-stream en código), que almacena las asociaciones entre Viewer y Stream.
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nickname;
    @ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)//LAZZY en session @Transactional
    @JoinTable(
            name = "followed_streams",
            joinColumns = @JoinColumn(name = "viewer_id"),
            inverseJoinColumns = @JoinColumn(name = "stream_id")
    )

    private Set<Stream> followedStreams = new HashSet<>();

    public Viewer(String nickname) {
        this.nickname = nickname;
    }

    public Viewer() {

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public Set<Stream> getFollowedStreams() {
        return followedStreams;
    }

    public void setFollowedStreams(Set<Stream> followedStreams) {
        this.followedStreams = followedStreams;
    }
}
