package com.upc.apprelacionesallrest.repository.manyToOne;

import com.upc.apprelacionesallrest.model.manyToOne.bidirection.Hijo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HijoRepository extends JpaRepository<Hijo, Long> {
}
