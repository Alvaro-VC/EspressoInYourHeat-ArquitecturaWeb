package com.upc.apprelacionesallrest.repository.manyToOne;

import com.upc.apprelacionesallrest.model.manyToOne.unidirection.University2;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface University2Repository extends JpaRepository<University2,Long> {
    @Query("SELECT COUNT(u) FROM Student2 s, University2 u WHERE s.status=true and s.university2.id =: id_U")
    int countUniversity2(Long id_U);
    //la cantidad de estudiantes con alumnos de status true de una universidad dada
}
