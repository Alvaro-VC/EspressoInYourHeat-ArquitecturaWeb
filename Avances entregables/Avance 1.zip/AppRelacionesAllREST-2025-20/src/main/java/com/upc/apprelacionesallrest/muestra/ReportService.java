package com.upc.apprelacionesallrest.muestra;

import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.concurrent.CompletableFuture;

@Service
public class ReportService
{
    public String generateSync()
    {
        slowIO();
        return "El reporte fue generado con éxito (SYNC)";
    }

    @Async("muestra")
    public CompletableFuture<String> generateAsync()
    {
        slowIO();
        return CompletableFuture.completedFuture("El reporte fue generado con éxito (ASYNC)");
    }

    private void slowIO()
    {
        try
        {
            Thread.sleep(2000);
        }
        catch (InterruptedException ignored){}
    }
}


