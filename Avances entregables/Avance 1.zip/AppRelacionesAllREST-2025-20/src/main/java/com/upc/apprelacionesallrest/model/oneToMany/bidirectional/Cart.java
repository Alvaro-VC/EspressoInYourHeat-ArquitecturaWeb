package com.upc.apprelacionesallrest.model.oneToMany.bidirectional;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.Data;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;
/**
 * Al serializar un objeto Padre (Cart), se incluirán los objetos Hijo (Item) asociados, pero cuando
 * se serializa un objeto Hijo, la referencia al objeto Padre no se incluirá, evitando la recursividad
 * infinita.
 */
@Entity
@Data
public class Cart {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String name;
    @OneToMany(mappedBy = "cart", cascade = CascadeType.ALL)
    @JsonManagedReference("cart_items") // Jackson serializa este lado de la relación normalmente (Padre=Cart).
    private List<Item> items = new ArrayList<>();
}

