package com.upc.apprelacionesallrest.controller;

import com.upc.apprelacionesallrest.model.manyToOne.bidirection.Hijo;
import com.upc.apprelacionesallrest.model.manyToOne.bidirection.Padre;
import com.upc.apprelacionesallrest.model.manyToOne.unidirection.Student2;
import com.upc.apprelacionesallrest.model.manyToOne.unidirection.University2;
import com.upc.apprelacionesallrest.model.oneToMany.unidirectional.Student;
import com.upc.apprelacionesallrest.negocio.Negocio;
import org.hibernate.id.enhanced.HiLoOptimizer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class ManyToOneController {

    @Autowired
    private Negocio negocio;

    @PostMapping("/student")
    public Student saveStudent(@RequestBody Student student){
        return negocio.saveStudent(student);
    }

    @PostMapping("/university2")
    public University2 saveUniversity(@RequestBody University2 university2){
        return negocio.saveUniversity2(university2);
    }
    @PostMapping("/student2")
    public Student2 saveStudent2(@RequestBody Student2 student2){
        return negocio.saveStudent2(student2);
    }

    @GetMapping("/university2")
    public List<University2> listUniversities2(){
        return negocio.listUniversities2();
    }

    @GetMapping("/student2")
    public List<Student2> listStudents2() {
        return negocio.listStundents2();
    }
    @PostMapping("/padre")
    public Padre savePadre(@RequestBody Padre padre){
        return negocio.savePadre(padre);
    }
    @PostMapping("/hijo")
    public Hijo saveHijo(@RequestBody Hijo hijo){
        return negocio.saveHijo(hijo);
    }

    @GetMapping("/padres")
    public List<Padre> listPadres(){
        return negocio.listPadres();
    }
    @GetMapping("/hijos")
    public List<Hijo> listHijos(){
        return negocio.listHijos();
    }


}
