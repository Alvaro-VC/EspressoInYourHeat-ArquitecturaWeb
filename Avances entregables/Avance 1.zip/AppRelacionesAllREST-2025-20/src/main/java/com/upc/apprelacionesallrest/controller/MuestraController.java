package com.upc.apprelacionesallrest.controller;

import com.upc.apprelacionesallrest.muestra.ReportService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.concurrent.CompletableFuture;

@RestController
@RequestMapping("/api/ej/muestra")
public class MuestraController
{
    private final ReportService service;

    public MuestraController(ReportService service)
    {
        this.service = service;
    }

    @GetMapping("/sync")
    public ResponseEntity<String> sync()
    {
        return ResponseEntity.ok(service.generateSync());
    }

    @GetMapping("/async")
    public CompletableFuture<ResponseEntity<String>> async()
    {
        return service.generateAsync()
                .thenApply(body -> ResponseEntity.ok()
                        .header("X-Async", "true")
                        .body(body));
    }

}
