package com.upc.appcafe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppcafeApplicationTests {

    @Test
    void contextLoads() {
    }

}
